#define MY_NAME "Stefan"
