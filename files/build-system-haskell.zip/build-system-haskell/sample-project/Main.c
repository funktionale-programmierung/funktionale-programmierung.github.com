#include "Auto.h"  /* generated automatically */
#include "Hello.h"

int main(int argc, char *argv[])
{
    say_hello(MY_NAME);
    return 0;
}
