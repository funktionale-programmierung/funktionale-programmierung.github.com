void say_hello(const char *name);
