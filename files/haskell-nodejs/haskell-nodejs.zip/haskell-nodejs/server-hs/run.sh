#!/bin/bash

./MainConduit +RTS -N
