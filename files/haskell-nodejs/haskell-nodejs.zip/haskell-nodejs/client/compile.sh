#!/bin/bash

ghc -threaded --make -O2 Main.hs
