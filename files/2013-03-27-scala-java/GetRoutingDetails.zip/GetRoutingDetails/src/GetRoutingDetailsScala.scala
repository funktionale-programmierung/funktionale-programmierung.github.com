object GetRoutingDetailsScalaC3 {
	def run(): (String, Int) = {
	  val (totalNodeCount, nodes) =
	    (0 until 126).foldLeft((0, List():List[String]))((state, routeNumber) => {
		    (0 until 125).foldLeft(state)(
		    	(state, infoNumber) => {
			    	val (totalNodeCount, nodes) = state
			    	(totalNodeCount + 1, 
			    			if (infoNumber == 0) nodes
			    			else ("YYZ" + infoNumber) :: nodes)
		    	})})
	    
	  val route = nodes.reverse.mkString("\n|") ++ "\n";

    System.err.print(route);
    System.out.print("Node Count: %d".format(totalNodeCount));
	  (route, totalNodeCount)
	}
}


object GetRoutingDetailsScalaC2 {
	def run(): (String, Int) = {
	  val routes = (0 until 126).map({routeNumber =>
	    val nodes = (1 until 125).map({infoNumber => "YYZ" + infoNumber})
	    (nodes.size + 1, nodes.mkString("\n|"))
	   })
	  val totalNodeCount = routes.map(x => x._1).sum
	  val route = routes.map(x => x._2).mkString("\n|") ++ "\n";

    System.err.print(route);
    System.out.print("Node Count: %d".format(totalNodeCount));
	  (route, totalNodeCount)
	}
}

class GetRoutingDetailsScalaC1 {
  var route = "";
  var totalNodeCount = -1;
  
	def run() {
	  val strRouteList = new StringBuilder()
	  var totalNodeCount = 0
	  for (routeNumber <- 0 until 126) {
	    var nodeCount = 0
	    for (infoNumber <- 0 until 125) {
	      val fromLocation = "YYZ";
	      val toLocation = "" + infoNumber
	      if (nodeCount != 0) {
	        if (totalNodeCount == 1)
	          strRouteList.append(fromLocation + toLocation);
	        else if (totalNodeCount > 1)
	          strRouteList.append("|" + fromLocation + toLocation)
          strRouteList.append("\n")
        }
	      nodeCount += 1
	      totalNodeCount += 1
	    }
	  }
	  
	  route = strRouteList.toString()
	  this.totalNodeCount = totalNodeCount
    java.lang.System.err.print(route);
    System.out.print("Node Count: %d".format(totalNodeCount));
	}
}

object GetRoutingDetailsScala1 extends App {
  val subRoutes = (0 until 126).map({routeNumber =>
    val nodes = (1 until 125).map({infoNumber => "YYZ" + infoNumber})
    (nodes.size + 1, nodes.mkString("\n|"))
   })
  val totalNodeCount = subRoutes.map(x => x._1).sum
  val route = subRoutes.map(x => x._2).mkString("\n|") ++ "\n";

  System.err.print(route);
  System.out.print("Node Count: %d".format(totalNodeCount));
}
