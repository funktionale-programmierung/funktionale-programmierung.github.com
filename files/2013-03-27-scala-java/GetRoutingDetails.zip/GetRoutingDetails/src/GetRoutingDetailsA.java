public class GetRoutingDetailsA {
	public String route = "";
	public int totalNodeCount = -1;
	
  public void run() {
    StringBuilder strRouteList = new StringBuilder();
    int totalNodeCount = 0;
    for(int routeNumber = 0; routeNumber < 126; routeNumber++) {
      int nodeCount = 0;
      for(int infoNumber = 0; infoNumber < 125; infoNumber++) {
        String fromLocation = "YYZ";
        String toLocation = ""+infoNumber;
        totalNodeCount++;
        if (nodeCount != 0) {
          if (strRouteList.toString().isEmpty())
            strRouteList.append(fromLocation + toLocation);
          else
            strRouteList.append("|" + fromLocation + toLocation);
          strRouteList.append("\n");
        }
        nodeCount++;

      }
    }
    route = strRouteList.toString();
    this.totalNodeCount = totalNodeCount;
    System.err.print(route);
    System.out.format("Node Count: %d",totalNodeCount);
    
  }
}
