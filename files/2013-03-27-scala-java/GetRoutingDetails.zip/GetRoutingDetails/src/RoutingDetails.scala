import scala.actors.threadpool.helpers.NanoTimer
object RoutingDetails extends App {
	val repeats = if (args.length > 0) args(0).toInt else 100
  def runMeasured[A](thunk:()=>A): (Long, A) = {
    val start = System.nanoTime()
    var result = thunk()
    (0 until repeats).foreach({_ => result = thunk()})
    val end = System.nanoTime()
    (end - start, result)
  }
	val A = new GetRoutingDetailsA()
	val B = new GetRoutingDetailsB()
//	val C = new GetRoutingDetailsScala()
	
	println("Getting routing details...");
	
	println("...from Java A:");
	val (durationA, _) = runMeasured({() => A.run()})
	println

	println("...from Java B:");
	val (durationB, _) = runMeasured({() =>B.run()})
	println

		println("...from Scala C2:");
	val (durationC2, (route2, totalNodeCount2)) = runMeasured({() => GetRoutingDetailsScalaC2.run()})
	println

	println("...from Scala C3:");
	val (durationC3, (route3, totalNodeCount3)) = runMeasured({() => GetRoutingDetailsScalaC3.run()})
	println

	println("...from Scala C1:");
	val C1 = new GetRoutingDetailsScalaC1()
	val (durationC1, (route1, totalNodeCount1)) = runMeasured({() => C1.run(); (C1.route, C1.totalNodeCount)})
	println

	println("Durations:")
	println(" A: %12d ns (= %3.0f x B)".format(durationA, durationA.toFloat/durationB));
	println(" B: %12d ns (= %3.0f x B)".format(durationB, durationB.toFloat/durationB));
	println("C2: %12d ns (= %3.0f x B)".format(durationC2, durationC2.toFloat/durationB));
	println("C3: %12d ns (= %3.0f x B)".format(durationC3, durationC3.toFloat/durationB));
	println("C1: %12d ns (= %3.0f x B)".format(durationC1, durationC1.toFloat/durationB));
	println("Checking consistency");
	println("B.route == C2.route                  : " + (B.route == route2))
	println("B.totalNodeCount == C2.totalNodeCount: " + (B.totalNodeCount == totalNodeCount2))
	
	println("B.route == C3.route                  : " + (B.route == route3))
	println("B.totalNodeCount == C3.totalNodeCount: " + (B.totalNodeCount == totalNodeCount3))

	println("B.route == C1.route                  : " + (B.route == route1))
	println("B.totalNodeCount == C1.totalNodeCount: " + (B.totalNodeCount == totalNodeCount1))
	
}